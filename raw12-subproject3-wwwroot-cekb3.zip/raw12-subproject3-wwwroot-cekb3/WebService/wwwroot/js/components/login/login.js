﻿define([], () => {
    return function () {

        return {

        };
    }
});