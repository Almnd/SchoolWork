﻿define([], () => {
    return function () {

    }
});