﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebService.Models
{
    public class GenreDto
    {
        public string TitleId { get; set; }
        public string Genre { get; set; }
        public string Url { get; set; }
    }
}
