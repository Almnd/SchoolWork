﻿namespace DataServiceLib.Moviedata
{
    public class Directors
    {
        //properties
        public string TitleId { get; set; }
        public string DirectorId { get; set; }

    }
}