﻿namespace DataServiceLib.Moviedata
{
    public class Languages
    {
        //properties
        public string TitleId { get; set; }
        public string Ordering { get; set; }
        public string Region { get; set; }
        public string Language { get; set; }

    }
}