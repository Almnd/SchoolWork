﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataServiceLib.Moviedata
{
    public class Actors
    {
        //properties
        public string Nconst { get; set; }
        public string PrimaryName { get; set; }

        //navigation properties
        //public string Type { get; set; } //dummy
    }
}