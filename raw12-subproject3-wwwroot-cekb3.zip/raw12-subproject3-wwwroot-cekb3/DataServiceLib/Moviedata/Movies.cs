﻿namespace DataServiceLib.Moviedata
{
    public class Movies
    {
        //properties
        public string TitleId { get; set; }
        public string TitleType { get; set; }
        public string PrimaryTitle { get; set; }

        //navigation poperties
        //public string Type { get; set; } //dummy
    }
}