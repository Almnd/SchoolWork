﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataServiceLib.Moviedata
{
    public class Genres
    {
        //properties
        public string TitleId { get; set; }
        public string Genre { get; set; }

        //navigation properties
        //public string Type { get; set; } //dummy
    }
}